



const express = require("express");
const user = require("../Model/model.user")

const usrRoutes = express.Router();

// add data 

usrRoutes.post("/addData", async (req, res) => {
    console.log(req.body)
    let newUser = new user({
        username : req.body.username,
        email : req.body.email,
        password : req.body.password
    })

    const savedUser = await newUser.save();
    console.log(savedUser)
    res.json({"userdata":savedUser})


})

// getData 
usrRoutes.get("/getData" , async(req,res)=>{

    const getData = await user.find()
    console.log(getData)
    res.send(getData)    
})









module.exports = usrRoutes;








    
//         const users = await User.find();
//         res.status(200).json(users);
    
// const nayauser = new user({
//     name: req.body.name,
//     email: req.body.email,
//     password: req.body.password
// })

// const savedUser = await nayauser.save();
// res.json(savedUser)
